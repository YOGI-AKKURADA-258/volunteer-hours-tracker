#!/usr/bin/env python3
"""Campus Catalyst - Volunteer Hours Tracker (Project #78).

Zero-dependency (standard library only), Python 3.10+.
Run:  python volunteer_tracker.py
"""
import csv                                   # CSV read/write for import/export
import json                                  # JSON persistence
import os                                    # file-exists checks, paths
import sys                                   # clean exit
from collections import defaultdict          # grouping totals by category/month
from dataclasses import dataclass, asdict    # typed record model
from datetime import date, datetime, timedelta  # date validation and trends

# ----------------------------------------------------------------- CONFIG
DATA_FILE = "volunteer_data.json"            # where records persist
CATEGORIES = ["Education", "Environment", "Health", "Community",
              "Safety", "Fundraising", "Other"]
MIN_HOURS, MAX_HOURS = 0.25, 24.0            # per-entry boundary limits
GOAL_HOURS = 100.0                           # service goal for status bar
WARN_SINGLE_ENTRY = 12.0                     # anomaly threshold (one entry)
WARN_INACTIVE_DAYS = 30                      # inactivity warning threshold
PAGE_SIZE = 10                               # rows per page in tables

# ANSI colours (harmless on terminals that ignore them)
CYAN, GREEN, YELLOW, RED, BOLD, RESET = (
    "\033[96m", "\033[92m", "\033[93m", "\033[91m", "\033[1m", "\033[0m")


# ------------------------------------------------------------ DATA MODEL
@dataclass
class Record:
    id: int
    date: str            # ISO format YYYY-MM-DD
    activity: str
    category: str
    hours: float
    organization: str
    notes: str = ""


# ------------------------------------------------------- VALIDATION LAYER
def validate_date(text: str) -> date:
    """Parse YYYY-MM-DD; reject future dates and dates older than 5 years."""
    d = datetime.strptime(text.strip(), "%Y-%m-%d").date()  # ValueError if bad
    today = date.today()
    if d > today:
        raise ValueError("date cannot be in the future")
    if d < today - timedelta(days=5 * 365):
        raise ValueError("date is more than 5 years old")
    return d


def validate_hours(text: str) -> float:
    """Convert to float and enforce MIN_HOURS..MAX_HOURS."""
    h = float(text.strip())                       # ValueError if non-numeric
    if h != h:                                    # NaN check
        raise ValueError("hours must be a number")
    if not (MIN_HOURS <= h <= MAX_HOURS):
        raise ValueError(f"hours must be between {MIN_HOURS} and {MAX_HOURS}")
    return round(h, 2)


def validate_text(text: str, label: str, max_len: int = 80) -> str:
    """Non-blank text, trimmed, no commas-breaking control chars."""
    t = " ".join(text.split())                    # collapse whitespace
    if not t:
        raise ValueError(f"{label} cannot be blank")
    if len(t) > max_len:
        raise ValueError(f"{label} must be <= {max_len} characters")
    return t


def validate_category(text: str) -> str:
    """Accept a category name (case-insensitive) or its menu number."""
    t = text.strip()
    if t.isdigit() and 1 <= int(t) <= len(CATEGORIES):
        return CATEGORIES[int(t) - 1]
    for c in CATEGORIES:
        if c.lower() == t.lower():
            return c
    raise ValueError("choose a listed category")


def ask(prompt: str, validator, **kw):
    """Centralised input wrapper: loops until the validator accepts."""
    while True:
        try:
            raw = input(f"{prompt}: ")
            return validator(raw, **kw) if kw else validator(raw)
        except ValueError as err:
            print(f"{RED}  x Invalid: {err}. Try again.{RESET}")
        except (EOFError, KeyboardInterrupt):
            print("\nInput cancelled.")
            raise


# --------------------------------------------------------- PERSISTENCE
def load_records(path: str = DATA_FILE) -> list[Record]:
    """Load JSON; recover from missing/corrupt files with a clean template."""
    if not os.path.exists(path):
        save_records([], path)
        return []
    try:
        with open(path, "r", encoding="utf-8") as f:
            raw = json.load(f)
        return [Record(**r) for r in raw]         # schema check via dataclass
    except (json.JSONDecodeError, TypeError, KeyError, OSError) as err:
        backup = path + ".corrupt"
        try:
            os.replace(path, backup)              # keep the bad file for review
        except OSError:
            pass
        print(f"{YELLOW}! Data file unreadable ({err}). "
              f"Backed up to {backup}; starting clean.{RESET}")
        save_records([], path)
        return []


def save_records(records: list[Record], path: str = DATA_FILE) -> None:
    """Atomic-ish write: write temp file then replace original."""
    tmp = path + ".tmp"
    with open(tmp, "w", encoding="utf-8") as f:
        json.dump([asdict(r) for r in records], f, indent=2)
    os.replace(tmp, path)


def next_id(records: list[Record]) -> int:
    return max((r.id for r in records), default=0) + 1


# ------------------------------------------------------ BUSINESS LOGIC
def total_hours(records: list[Record]) -> float:
    return round(sum(r.hours for r in records), 2)


def hours_by(records: list[Record], key) -> dict[str, float]:
    """Group-and-sum helper (category, month, organization...)."""
    out: dict[str, float] = defaultdict(float)
    for r in records:
        out[key(r)] += r.hours
    return {k: round(v, 2) for k, v in out.items()}


def warnings_for(records: list[Record]) -> list[str]:
    """Threshold warning flags."""
    msgs = []
    for r in records:
        if r.hours >= WARN_SINGLE_ENTRY:
            msgs.append(f"Entry #{r.id} logs {r.hours}h in one day "
                        f"(>= {WARN_SINGLE_ENTRY}h) - verify.")
    seen = defaultdict(int)
    for r in records:
        seen[(r.date, r.activity.lower())] += 1
    for (d, a), n in seen.items():
        if n > 1:
            msgs.append(f"Possible duplicate: '{a}' on {d} logged {n} times.")
    if records:
        last = max(date.fromisoformat(r.date) for r in records)
        gap = (date.today() - last).days
        if gap > WARN_INACTIVE_DAYS:
            msgs.append(f"No volunteering logged for {gap} days.")
    total = total_hours(records)
    if total >= GOAL_HOURS:
        msgs.append(f"Goal of {GOAL_HOURS:.0f}h reached!")
    return msgs


# ---------------------------------------------------------- PRESENTATION
def banner() -> None:
    print(f"{CYAN}{BOLD}")
    print("=" * 56)
    print("   CAMPUS CATALYST  |  VOLUNTEER HOURS TRACKER")
    print("   Safety & Community - Project #78")
    print("=" * 56 + RESET)


def table(rows: list[Record]) -> None:
    """Fixed-width table with pagination."""
    if not rows:
        print(f"{YELLOW}  (no records){RESET}")
        return
    head = f"{'ID':>4} | {'Date':<10} | {'Activity':<24} | {'Category':<12} | {'Hrs':>5} | Organization"
    for start in range(0, len(rows), PAGE_SIZE):
        print(BOLD + head + RESET)
        print("-" * len(head))
        for r in rows[start:start + PAGE_SIZE]:
            print(f"{r.id:>4} | {r.date:<10} | {r.activity[:24]:<24} | "
                  f"{r.category:<12} | {r.hours:>5.2f} | {r.organization[:22]}")
        if start + PAGE_SIZE < len(rows):
            ans = input(f"-- {start + PAGE_SIZE}/{len(rows)} shown. "
                        "Enter = next page, q = stop: ").strip().lower()
            if ans == "q":
                break


def bar(value: float, maximum: float, width: int = 30) -> str:
    filled = int(width * value / maximum) if maximum else 0
    return "#" * filled + "." * (width - filled)


def summary_text(records: list[Record]) -> str:
    """Executive summary as plain text (reused by screen and exports)."""
    if not records:
        return "No records yet."
    total = total_hours(records)
    avg = total / len(records)
    longest = max(records, key=lambda r: r.hours)
    by_cat = hours_by(records, lambda r: r.category)
    by_month = hours_by(records, lambda r: r.date[:7])
    by_org = hours_by(records, lambda r: r.organization)
    pct = min(100.0, total / GOAL_HOURS * 100)
    lines = [
        "EXECUTIVE SUMMARY",
        "=" * 40,
        f"Total entries      : {len(records)}",
        f"Total hours        : {total:.2f}",
        f"Average per entry  : {avg:.2f}",
        f"Longest session    : {longest.hours:.2f}h ({longest.activity}, {longest.date})",
        f"Goal progress      : [{bar(total, GOAL_HOURS)}] {pct:.0f}% of {GOAL_HOURS:.0f}h",
        "", "Hours by category:",
    ]
    top = max(by_cat.values())
    for k, v in sorted(by_cat.items(), key=lambda kv: -kv[1]):
        lines.append(f"  {k:<13}{v:>7.2f}  {bar(v, top, 20)}")
    lines += ["", "Monthly trend:"]
    months = sorted(by_month)
    for i, m in enumerate(months):
        arrow = ""
        if i:
            diff = by_month[m] - by_month[months[i - 1]]
            arrow = "  ^" if diff > 0 else "  v" if diff < 0 else "  ="
        lines.append(f"  {m}  {by_month[m]:>7.2f}{arrow}")
    best = max(by_org.items(), key=lambda kv: kv[1])
    lines += ["", f"Top organization   : {best[0]} ({best[1]:.2f}h)"]
    return "\n".join(lines)


# ---------------------------------------------------------- MENU ACTIONS
def add_entry(records: list[Record]) -> None:
    print(f"\n{BOLD}Log a volunteer activity{RESET}  (Ctrl+C to cancel)")
    try:
        d = ask("Date (YYYY-MM-DD)", validate_date)
        act = ask("Activity", validate_text, label="Activity")
        for i, c in enumerate(CATEGORIES, 1):
            print(f"   {i}. {c}")
        cat = ask("Category (number or name)", validate_category)
        hrs = ask(f"Hours ({MIN_HOURS}-{MAX_HOURS})", validate_hours)
        org = ask("Organization", validate_text, label="Organization")
        notes = input("Notes (optional): ").strip()[:200]
    except (EOFError, KeyboardInterrupt):
        print("Entry cancelled.")
        return
    rec = Record(next_id(records), d.isoformat(), act, cat, hrs, org, notes)
    records.append(rec)
    save_records(records)
    print(f"{GREEN}  + Saved entry #{rec.id}. Running total: "
          f"{total_hours(records):.2f}h{RESET}")
    if hrs >= WARN_SINGLE_ENTRY:
        print(f"{YELLOW}  ! Warning: unusually long session ({hrs}h).{RESET}")


def view_all(records: list[Record]) -> None:
    table(sorted(records, key=lambda r: r.date, reverse=True))


def search(records: list[Record]) -> None:
    kw = input("Keyword (blank = any): ").strip().lower()
    cat_in = input("Category filter (blank = any): ").strip()
    cat = None
    if cat_in:
        try:
            cat = validate_category(cat_in)
        except ValueError as err:
            print(f"{RED}  x {err}{RESET}")
            return
    hits = [r for r in records
            if (not kw or kw in f"{r.activity} {r.organization} {r.notes}".lower())
            and (cat is None or r.category == cat)]
    print(f"{len(hits)} match(es), {total_hours(hits):.2f}h")
    table(hits)


def delete_entry(records: list[Record]) -> None:
    try:
        rid = int(input("Entry ID to delete: "))
    except ValueError:
        print(f"{RED}  x ID must be a number.{RESET}")
        return
    for r in records:
        if r.id == rid:
            if input(f"Delete '{r.activity}' ({r.hours}h)? [y/N]: ").lower() == "y":
                records.remove(r)
                save_records(records)
                print(f"{GREEN}  Deleted.{RESET}")
            return
    print(f"{RED}  x No entry with that ID.{RESET}")


def show_summary(records: list[Record]) -> None:
    print("\n" + summary_text(records))
    for w in warnings_for(records):
        print(f"{YELLOW}  ! {w}{RESET}")


def export_reports(records: list[Record]) -> None:
    if not records:
        print(f"{YELLOW}  Nothing to export.{RESET}")
        return
    os.makedirs("reports", exist_ok=True)
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S")
    base = os.path.join("reports", f"report_{stamp}")
    with open(base + ".csv", "w", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=list(asdict(records[0]).keys()))
        w.writeheader()
        w.writerows(asdict(r) for r in records)
    with open(base + ".txt", "w", encoding="utf-8") as f:
        f.write(summary_text(records) + "\n\nWARNINGS:\n")
        f.write("\n".join(f"- {w}" for w in warnings_for(records)) or "- none")
    with open(base + ".md", "w", encoding="utf-8") as f:
        f.write("# Volunteer Hours Report\n\n")
        f.write(f"*Generated {datetime.now():%Y-%m-%d %H:%M}*\n\n")
        f.write(f"**Total hours:** {total_hours(records):.2f}  \n")
        f.write(f"**Entries:** {len(records)}\n\n")
        f.write("| ID | Date | Activity | Category | Hours | Organization |\n")
        f.write("|---:|------|----------|----------|------:|--------------|\n")
        for r in sorted(records, key=lambda x: x.date):
            f.write(f"| {r.id} | {r.date} | {r.activity} | {r.category} "
                    f"| {r.hours:.2f} | {r.organization} |\n")
    print(f"{GREEN}  Exported: {base}.csv / .txt / .md{RESET}")


def bulk_import(records: list[Record]) -> None:
    """Import legacy CSV (columns: date,activity,category,hours,organization,notes)."""
    path = input("CSV path: ").strip().strip('"')
    if not os.path.isfile(path):
        print(f"{RED}  x File not found.{RESET}")
        return
    ok, errors = 0, []
    try:
        with open(path, newline="", encoding="utf-8-sig") as f:
            reader = csv.DictReader(f)
            need = {"date", "activity", "category", "hours", "organization"}
            if not reader.fieldnames or not need <= {h.strip().lower() for h in reader.fieldnames}:
                print(f"{RED}  x CSV needs columns: {', '.join(sorted(need))}{RESET}")
                return
            for n, row in enumerate(reader, start=2):   # row 1 is the header
                row = {k.strip().lower(): (v or "") for k, v in row.items() if k}
                try:
                    rec = Record(
                        next_id(records),
                        validate_date(row["date"]).isoformat(),
                        validate_text(row["activity"], "Activity"),
                        validate_category(row["category"]),
                        validate_hours(row["hours"]),
                        validate_text(row["organization"], "Organization"),
                        row.get("notes", "")[:200],
                    )
                    records.append(rec)
                    ok += 1
                except ValueError as err:
                    errors.append(f"row {n}: {err}")
    except (OSError, csv.Error, UnicodeDecodeError) as err:
        print(f"{RED}  x Could not read file: {err}{RESET}")
        return
    save_records(records)
    print(f"{GREEN}  Imported {ok} row(s).{RESET} {len(errors)} rejected.")
    if errors:
        with open("import_errors.log", "w", encoding="utf-8") as f:
            f.write("\n".join(errors))
        print(f"{YELLOW}  Details in import_errors.log{RESET}")
        for e in errors[:5]:
            print("   ", e)


def seed_demo(records: list[Record]) -> None:
    """Add 36 realistic demo entries (normal, boundary and edge cases)."""
    if records and input("Data exists. Add demo data anyway? [y/N]: ").lower() != "y":
        return
    acts = [("Food bank sorting", "Community", "City Food Bank"),
            ("Beach clean-up", "Environment", "Green Coast"),
            ("Peer tutoring", "Education", "Campus Learning Hub"),
            ("First-aid booth", "Health", "Red Cross Club"),
            ("Night safety walk", "Safety", "Campus Safety Team"),
            ("Charity run marshal", "Fundraising", "Run4Good")]
    today = date.today()
    hours_cycle = [2, 3.5, 4, 1.5, 0.25, 24, 6, 2.75, 12, 5]   # includes boundaries
    for i in range(36):
        a, c, o = acts[i % len(acts)]
        d = today - timedelta(days=i * 4 + 1)
        records.append(Record(next_id(records), d.isoformat(), a, c,
                              float(hours_cycle[i % len(hours_cycle)]), o,
                              "demo data"))
    records.append(records[-1].__class__(next_id(records), records[-1].date,
                                         records[-1].activity, records[-1].category,
                                         records[-1].hours, records[-1].organization,
                                         "duplicate edge case"))
    save_records(records)
    print(f"{GREEN}  Added demo data. Total entries: {len(records)}{RESET}")


# ------------------------------------------------------------ MAIN LOOP
MENU = """
 1. Log new activity       5. Export reports (CSV/TXT/MD)
 2. View all records       6. Bulk import CSV
 3. Search / filter        7. Delete an entry
 4. Executive summary      8. Load demo data
 0. Exit
"""


def main() -> None:
    records = load_records()
    banner()
    print(f"Loaded {len(records)} record(s), {total_hours(records):.2f} hours.")
    actions = {"1": add_entry, "2": view_all, "3": search, "4": show_summary,
               "5": export_reports, "6": bulk_import, "7": delete_entry,
               "8": seed_demo}
    while True:
        print(MENU)
        try:
            choice = input("Select option: ").strip()
        except (EOFError, KeyboardInterrupt):
            choice = "0"
        if choice == "0":
            save_records(records)
            print("Goodbye - your data is saved.")
            sys.exit(0)
        action = actions.get(choice)
        if action:
            action(records)
        else:
            print(f"{RED}  x Choose a number from the menu.{RESET}")


if __name__ == "__main__":
    main()
