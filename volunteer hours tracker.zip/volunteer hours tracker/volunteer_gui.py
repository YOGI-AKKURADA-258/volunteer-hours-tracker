"""Campus Catalyst: a fitness-inspired volunteer activity dashboard.

Run beside volunteer_tracker.py with: python volunteer_gui.py
Uses only the Python standard library.
"""
import csv
import ctypes
import os
import tkinter as tk
from datetime import date, timedelta
from tkinter import filedialog, messagebox, ttk

import volunteer_tracker as vt


BG, SIDEBAR, CARD, FIELD = "#111612", "#0b100d", "#1a211c", "#111813"
BORDER, ACCENT, TEXT, MUTED = "#303a31", "#c4f56c", "#f3f6ee", "#a0ad9e"
TEAL, AMBER, ERROR, FONT = "#79dbbf", "#f2c879", "#ffaaa2", "Segoe UI"
CATEGORY_COLORS = (ACCENT, TEAL, "#b5b1f5", AMBER, "#f2a99b", "#99c9f3", "#bac4b4")


def hours(value):
    return f"{value:,.1f}"


def short(text, limit=42):
    return text if len(text) <= limit else text[:limit - 1] + "…"


def label(parent, text="", size=10, color=TEXT, bold=False, **kwargs):
    return tk.Label(parent, text=text, bg=parent.cget("bg"), fg=color,
                    font=(FONT, size, "bold" if bold else "normal"), **kwargs)


def button(parent, text, command, primary=False, compact=False):
    background = ACCENT if primary else "#283329"
    hover = "#d6ff91" if primary else "#354336"
    widget = tk.Button(
        parent, text=text, command=command, bg=background,
        fg=SIDEBAR if primary else TEXT, activebackground=hover,
        activeforeground=SIDEBAR if primary else TEXT, relief="flat", bd=0,
        font=(FONT, 10, "bold"), padx=14, pady=7 if compact else 10,
        cursor="hand2", highlightthickness=1, highlightbackground=background,
        highlightcolor=ACCENT, takefocus=True)
    widget.bind("<Enter>", lambda event: widget.config(bg=hover))
    widget.bind("<Leave>", lambda event: widget.config(bg=background))
    return widget


def card(parent, padding=18):
    outer = tk.Frame(parent, bg=CARD, highlightbackground=BORDER,
                     highlightthickness=1, bd=0)
    inner = tk.Frame(outer, bg=CARD)
    inner.pack(fill="both", expand=True, padx=padding, pady=padding)
    return outer, inner


class ProgressRing(tk.Canvas):
    def __init__(self, parent, size=158):
        super().__init__(parent, width=size, height=size, bg=parent.cget("bg"),
                         highlightthickness=0, bd=0)
        self.value = 0
        self.bind("<Configure>", lambda event: self.draw())

    def set(self, value):
        self.value = value
        self.draw()

    def draw(self):
        self.delete("all")
        width, height = self.winfo_width(), self.winfo_height()
        if width <= 1:
            return
        size = min(width, height) - 20
        x, y = (width - size) / 2, (height - size) / 2
        box = (x, y, x + size, y + size)
        fraction = max(0, min(self.value / vt.GOAL_HOURS, 1))
        self.create_oval(*box, outline="#354332", width=11)
        if fraction >= 1:
            self.create_oval(*box, outline=ACCENT, width=11)
        elif fraction:
            self.create_arc(*box, start=90, extent=-min(359.99, fraction * 360),
                            outline=ACCENT, width=11, style="arc")
        self.create_text(width / 2, height / 2 - 6, text=f"{fraction:.0%}",
                         fill=TEXT, font=(FONT, 27, "bold"))
        self.create_text(width / 2, height / 2 + 25, text="OF YOUR GOAL",
                         fill=MUTED, font=(FONT, 8, "bold"))


class WeeklyChart(tk.Canvas):
    def __init__(self, parent):
        super().__init__(parent, bg=CARD, height=140, highlightthickness=0)
        self.values = [0] * 7
        self.bind("<Configure>", lambda event: self.draw())

    def set(self, values):
        self.values = values
        self.draw()

    def draw(self):
        self.delete("all")
        width, height = self.winfo_width(), self.winfo_height()
        if width < 10:
            return
        maximum = max(max(self.values), 1)
        left, right, top, bottom = max(30, len(f"{maximum:g}h") * 7 + 8), width - 8, 24, height - 25
        for fraction in (0, 0.5, 1):
            y = bottom - (bottom - top) * fraction
            self.create_line(left, y, right, y, fill=BORDER, dash=(2, 5))
        self.create_text(left - 6, top, text=f"{maximum:g}h", anchor="e",
                         fill=MUTED, font=(FONT, 8))
        monday = date.today() - timedelta(days=date.today().weekday())
        slot = (right - left) / 7
        bar_width = min(25, slot * 0.5)
        for index, value in enumerate(self.values):
            x = left + slot * (index + 0.5)
            today = index == date.today().weekday()
            bar_top = bottom - (bottom - top) * value / maximum
            self.create_rectangle(x - bar_width / 2, bar_top if value else bottom - 3,
                                  x + bar_width / 2, bottom,
                                  fill=ACCENT if today else TEAL if value else BORDER,
                                  outline="")
            if value:
                self.create_text(x, bar_top - 11, text=f"{value:g}", fill=TEXT,
                                 font=(FONT, 8, "bold"))
            self.create_text(x, height - 9,
                             text=(monday + timedelta(days=index)).strftime("%a"),
                             fill=ACCENT if today else MUTED, font=(FONT, 8))


class CategoryChart(tk.Canvas):
    def __init__(self, parent):
        super().__init__(parent, bg=CARD, height=175, highlightthickness=0)
        self.values = {}
        self.bind("<Configure>", lambda event: self.draw())

    def set(self, values):
        self.values = values
        self.draw()

    def draw(self):
        self.delete("all")
        width = self.winfo_width()
        if width < 10:
            return
        if not self.values:
            self.create_text(0, 40, anchor="nw", text="Log an activity to see your impact mix.",
                             fill=MUTED, font=(FONT, 10))
            return
        maximum = max(self.values.values()) or 1
        rows = sorted(self.values.items(), key=lambda item: -item[1])
        spacing = min(29, max(22, (self.winfo_height() - 8) / len(rows)))
        for index, (name, value) in enumerate(rows):
            y = 13 + index * spacing
            color = CATEGORY_COLORS[vt.CATEGORIES.index(name)] if name in vt.CATEGORIES else ACCENT
            self.create_text(0, y, text=name, fill=MUTED, anchor="w", font=(FONT, 9))
            start, end = 108, max(109, width - 65)
            self.create_line(start, y, end, y, fill=BORDER, width=7, capstyle="round")
            self.create_line(start, y, start + (end - start) * value / maximum, y,
                             fill=color, width=7, capstyle="round")
            self.create_text(width - 1, y, text=f"{hours(value)} h", fill=TEXT,
                             anchor="e", font=(FONT, 9, "bold"))


class App(tk.Tk):
    def __init__(self):
        super().__init__()
        self.title("Campus Catalyst | Activity & Impact")
        screen_width, screen_height = self.winfo_screenwidth(), self.winfo_screenheight()
        left, top = 0, 0
        if os.name == "nt":
            # Use the desktop work area so the taskbar never covers the footer.
            from ctypes import wintypes
            work = wintypes.RECT()
            if ctypes.windll.user32.SystemParametersInfoW(48, 0, ctypes.byref(work), 0):
                left, top = work.left, work.top
                screen_width, screen_height = work.right - work.left, work.bottom - work.top
        width, height = min(1180, screen_width - 40), min(730, screen_height - 60)
        self.geometry(f"{width}x{height}+{left + 20}+{top + 15}")
        self.minsize(1020, 660)
        self.configure(bg=BG)
        self.records = vt.load_records()
        self.status = tk.StringVar(value="Ready")
        self.current_page = "dashboard"
        self._style()
        self._shell()
        self._build_dashboard()
        self._build_log()
        self._build_records()
        self._build_summary()
        self.refresh_all()
        self.show_page("dashboard")
        self.bind("<Control-n>", self._new_shortcut)
        self.bind("<Control-s>", self._save_shortcut)

    def _style(self):
        style = ttk.Style(self)
        style.theme_use("clam")
        style.configure("TEntry", fieldbackground=FIELD, foreground=TEXT,
                        insertcolor=ACCENT, bordercolor=BORDER, lightcolor=BORDER,
                        darkcolor=BORDER, padding=(10, 9), font=(FONT, 10))
        style.map("TEntry", bordercolor=[("focus", ACCENT)],
                  lightcolor=[("focus", ACCENT)], darkcolor=[("focus", ACCENT)])
        style.configure("TCombobox", fieldbackground=FIELD, background=FIELD,
                        foreground=TEXT, arrowcolor=MUTED, bordercolor=BORDER,
                        lightcolor=BORDER, darkcolor=BORDER, padding=(9, 9))
        style.map("TCombobox", fieldbackground=[("readonly", FIELD)],
                  foreground=[("readonly", TEXT)], background=[("active", BORDER)],
                  bordercolor=[("focus", ACCENT)])
        style.configure("TSpinbox", fieldbackground=FIELD, background=FIELD,
                        foreground=TEXT, arrowcolor=MUTED, insertcolor=ACCENT,
                        bordercolor=BORDER, lightcolor=BORDER, darkcolor=BORDER,
                        padding=(10, 9))
        style.map("TSpinbox", bordercolor=[("focus", ACCENT)])
        style.configure("Treeview", background=CARD, fieldbackground=CARD,
                        foreground=TEXT, borderwidth=0, rowheight=43, font=(FONT, 10))
        style.configure("Treeview.Heading", background=FIELD, foreground=MUTED,
                        font=(FONT, 9, "bold"), padding=(10, 12), relief="flat")
        style.map("Treeview", background=[("selected", "#3c5130")],
                  foreground=[("selected", TEXT)])
        style.map("Treeview.Heading", background=[("active", "#29372a")])
        style.configure("Vertical.TScrollbar", background=BORDER, troughcolor=CARD,
                        borderwidth=0, arrowcolor=MUTED, width=11,
                        lightcolor=BORDER, darkcolor=BORDER, bordercolor=CARD)
        style.configure("Horizontal.TScrollbar", background=BORDER, troughcolor=CARD,
                        borderwidth=0, arrowcolor=MUTED, width=11,
                        lightcolor=BORDER, darkcolor=BORDER, bordercolor=CARD)
        for name in ("Vertical.TScrollbar", "Horizontal.TScrollbar"):
            style.map(name, background=[("disabled", CARD), ("active", "#4b5c49"), ("!disabled", BORDER)],
                      arrowcolor=[("disabled", "#4f5e4b"), ("!disabled", MUTED)])
        self.option_add("*TCombobox*Listbox.background", FIELD)
        self.option_add("*TCombobox*Listbox.foreground", TEXT)
        self.option_add("*TCombobox*Listbox.selectBackground", "#3c5130")
        self.option_add("*TCombobox*Listbox.selectForeground", TEXT)
        self.option_add("*TCombobox*Listbox.font", (FONT, 10))

    def _shell(self):
        sidebar = tk.Frame(self, bg=SIDEBAR, width=194)
        sidebar.pack(side="left", fill="y")
        sidebar.pack_propagate(False)
        brand = tk.Frame(sidebar, bg=SIDEBAR)
        brand.pack(fill="x", padx=22, pady=(28, 32))
        icon = tk.Canvas(brand, width=34, height=32, bg=SIDEBAR, highlightthickness=0)
        icon.pack(anchor="w", pady=(0, 10))
        icon.create_rectangle(0, 0, 32, 31, fill=ACCENT, outline="")
        icon.create_line(4, 17, 10, 17, 14, 8, 19, 25, 23, 14, 29, 14,
                         fill=SIDEBAR, width=2.5, joinstyle="round")
        label(brand, "CAMPUS", size=15, bold=True).pack(anchor="w")
        label(brand, "CATALYST", size=15, color=ACCENT, bold=True).pack(anchor="w")
        label(brand, "Small actions. Real impact.", size=8, color=MUTED).pack(anchor="w", pady=(8, 0))
        label(sidebar, "YOUR WORKSPACE", size=8, color=MUTED, bold=True).pack(anchor="w", padx=22, pady=(0, 12))
        self.nav = {}
        for key, title, symbol in (("dashboard", "Overview", "◈"),
                                    ("log", "Log activity", "+"),
                                    ("records", "Activity history", "≡"),
                                    ("summary", "Insights", "↗")):
            nav = tk.Button(sidebar, text=f"{symbol}   {title}", anchor="w",
                            command=lambda key=key: self.show_page(key),
                            bg=SIDEBAR, fg=MUTED, activebackground="#243022",
                            activeforeground=ACCENT, font=(FONT, 10, "bold"),
                            relief="flat", bd=0, padx=14, pady=13, cursor="hand2",
                            highlightthickness=1, highlightbackground=SIDEBAR,
                            highlightcolor=ACCENT)
            nav.pack(fill="x", padx=12, pady=3)
            self.nav[key] = nav
        bottom = tk.Frame(sidebar, bg=SIDEBAR)
        bottom.pack(side="bottom", fill="x", padx=20, pady=24)
        label(bottom, "KEEP SHOWING UP", size=8, color=ACCENT, bold=True).pack(anchor="w")
        label(bottom, "A little time.\nA lasting difference.", size=11, bold=True,
              justify="left").pack(anchor="w", pady=(8, 16))
        self.sidebar_progress = tk.Canvas(bottom, height=5, bg=SIDEBAR, highlightthickness=0)
        self.sidebar_progress.pack(fill="x")
        self.sidebar_progress.bind("<Configure>", lambda event: self._draw_sidebar_goal())
        self.sidebar_goal = label(bottom, color=MUTED, size=9)
        self.sidebar_goal.pack(anchor="w", pady=(8, 16))
        label(bottom, "VOLUNTEER HOURS TRACKER", size=7, color=MUTED).pack(anchor="w")

        main = tk.Frame(self, bg=BG)
        main.pack(side="left", fill="both", expand=True)
        header = tk.Frame(main, bg=BG)
        header.pack(fill="x", padx=26, pady=(23, 19))
        heading = tk.Frame(header, bg=BG)
        heading.pack(side="left", fill="x", expand=True)
        self.page_title = label(heading, size=23, bold=True)
        self.page_title.pack(anchor="w")
        self.page_subtitle = label(heading, size=9, color=MUTED)
        self.page_subtitle.pack(anchor="w", pady=(4, 0))
        button(header, "+  Log activity", lambda: self.show_page("log"), primary=True).pack(side="right")
        label(header, date.today().strftime("%a, %d %b"), size=9, color=MUTED).pack(side="right", padx=16)
        footer = tk.Frame(main, bg=BG)
        footer.pack(side="bottom", fill="x", padx=26, pady=(0, 12))
        label(footer, textvariable=self.status, size=8, color=MUTED, anchor="w").pack(side="left")
        label(footer, "Ctrl+N  New activity", size=8, color=MUTED).pack(side="right")
        self.content = tk.Frame(main, bg=BG)
        self.content.pack(fill="both", expand=True, padx=26, pady=(0, 12))
        self.pages = {key: tk.Frame(self.content, bg=BG) for key in self.nav}
        self.tab_log = self.pages["log"]
        self.tab_rec = self.pages["records"]
        self.tab_sum = self.pages["summary"]

    def show_page(self, key):
        self.current_page = key
        for name, page in self.pages.items():
            page.pack_forget()
            self.nav[name].config(bg="#263222" if name == key else SIDEBAR,
                                  fg=ACCENT if name == key else MUTED)
        self.pages[key].pack(fill="both", expand=True)
        title, subtitle = {
            "dashboard": ("Your impact, in motion.", "Every session is a step toward a stronger community."),
            "log": ("Make today count.", "Log your volunteer activity and keep your momentum going."),
            "records": ("Your activity history.", "All the time you have given, in one place."),
            "summary": ("See how far you've come.", "A closer look at your progress, patterns and community impact."),
        }[key]
        self.page_title.config(text=title)
        self.page_subtitle.config(text=subtitle)
        self.refresh_all()

    def _new_shortcut(self, event=None):
        self.show_page("log")
        self.activity_entry.focus_set()
        return "break"

    def _save_shortcut(self, event=None):
        if self.current_page == "log":
            self.save_entry()
        return "break"

    def _build_dashboard(self):
        page = self.pages["dashboard"]
        metrics = tk.Frame(page, bg=BG)
        metrics.pack(fill="x", pady=(0, 14))
        self.metric_values = {}
        for index, (key, title, hint, color) in enumerate((
                ("total", "TOTAL HOURS", "Time well spent", ACCENT),
                ("week", "THIS WEEK", "Monday – Sunday", TEAL),
                ("sessions", "ACTIVITIES", "Every effort matters", "#b5b1f5"),
                ("orgs", "ORGANIZATIONS", "Connections that count", AMBER))):
            metrics.columnconfigure(index, weight=1, uniform="metric")
            outer, inner = card(metrics, padding=13)
            outer.grid(row=0, column=index, sticky="nsew", padx=(0 if index == 0 else 6, 0 if index == 3 else 6))
            label(inner, title, size=8, color=MUTED, bold=True).pack(anchor="w")
            value = label(inner, "0", size=25, color=color, bold=True)
            value.pack(anchor="w", pady=(2, 0))
            label(inner, hint, size=8, color=MUTED).pack(anchor="w")
            self.metric_values[key] = value

        middle = tk.Frame(page, bg=BG)
        middle.pack(fill="x", pady=(0, 14))
        middle.columnconfigure(0, weight=6, uniform="middle")
        middle.columnconfigure(1, weight=5, uniform="middle")
        outer, hero = card(middle, padding=18)
        outer.grid(row=0, column=0, sticky="nsew", padx=(0, 7))
        self.dashboard_ring = ProgressRing(hero, size=156)
        self.dashboard_ring.pack(side="right", padx=(8, 0))
        copy = tk.Frame(hero, bg=CARD)
        copy.pack(side="left", fill="both", expand=True)
        label(copy, "THE BIG PICTURE", size=8, color=ACCENT, bold=True).pack(anchor="w")
        label(copy, "Every hour\nmakes an impact.", size=18, bold=True,
              justify="left").pack(anchor="w", pady=(10, 9))
        self.goal_caption = label(copy, size=9, color=MUTED)
        self.goal_caption.pack(anchor="w")
        self.goal_remaining = label(copy, size=9, color=ACCENT)
        self.goal_remaining.pack(anchor="w", pady=(5, 0))
        outer, chart = card(middle, padding=16)
        outer.grid(row=0, column=1, sticky="nsew", padx=(7, 0))
        chart_head = tk.Frame(chart, bg=CARD)
        chart_head.pack(fill="x")
        label(chart_head, "Weekly rhythm", size=12, bold=True).pack(side="left")
        label(chart_head, "HOURS", size=8, color=MUTED).pack(side="right")
        self.weekly_chart = WeeklyChart(chart)
        self.weekly_chart.pack(fill="both", expand=True, pady=(8, 0))

        outer, recent = card(page, padding=14)
        outer.pack(fill="both", expand=True)
        recent_head = tk.Frame(recent, bg=CARD)
        recent_head.pack(fill="x", pady=(0, 8))
        label(recent_head, "Recent activity", size=12, bold=True).pack(side="left")
        button(recent_head, "View all  →", lambda: self.show_page("records"), compact=True).pack(side="right")
        self.recent_area = tk.Frame(recent, bg=CARD, height=150)
        self.recent_area.pack(fill="both", expand=True)
        self.recent_area.pack_propagate(False)
        self.recent_rows = []
        self.recent_area.bind("<Configure>", lambda event: self._layout_recent())

    def _build_log(self):
        page = self.tab_log
        page.columnconfigure(0, weight=5, uniform="log")
        page.columnconfigure(1, weight=3, uniform="log")
        page.rowconfigure(0, weight=1)
        outer, form = card(page, padding=21)
        outer.grid(row=0, column=0, sticky="nsew", padx=(0, 14))
        label(form, "New activity", size=15, bold=True).pack(anchor="w")
        label(form, "A small commitment. A meaningful contribution.", size=9, color=MUTED).pack(anchor="w", pady=(5, 12))
        fields = tk.Frame(form, bg=CARD)
        fields.pack(fill="both", expand=True)
        fields.columnconfigure(0, weight=1, uniform="fields")
        fields.columnconfigure(1, weight=1, uniform="fields")
        self.v = {key: tk.StringVar() for key in ("date", "activity", "category", "hours", "org")}
        self.v["date"].set(date.today().isoformat())
        self.v["category"].set(vt.CATEGORIES[0])
        self.v["hours"].set("1")
        specs = (("Date  ·  YYYY-MM-DD", "date", 0, 0, 1),
                 ("Duration  ·  hours", "hours", 0, 1, 1),
                 ("Activity name", "activity", 2, 0, 2),
                 ("Category", "category", 4, 0, 1),
                 ("Organization", "org", 4, 1, 1))
        for title, key, row, column, span in specs:
            padx = (0, 8) if span == 1 and column == 0 else (8, 0) if column else 0
            label(fields, title, size=9, color=MUTED).grid(row=row, column=column,
                  columnspan=span, sticky="w", padx=padx, pady=(0, 5))
            if key == "category":
                widget = ttk.Combobox(fields, textvariable=self.v[key], values=vt.CATEGORIES,
                                      state="readonly", font=(FONT, 10), width=14)
            elif key == "hours":
                widget = ttk.Spinbox(fields, textvariable=self.v[key], from_=vt.MIN_HOURS,
                                     to=vt.MAX_HOURS, increment=0.25, font=(FONT, 10), width=12)
            else:
                widget = ttk.Entry(fields, textvariable=self.v[key], font=(FONT, 10), width=15)
            widget.grid(row=row + 1, column=column, columnspan=span, sticky="ew", padx=padx, pady=(0, 10))
            if key == "activity":
                self.activity_entry = widget
        label(fields, "Notes  ·  optional", size=9, color=MUTED).grid(row=6, column=0, sticky="w", pady=(0, 6))
        self.notes = tk.Text(fields, height=3, width=20, font=(FONT, 10), relief="flat",
                             bg=FIELD, fg=TEXT, insertbackground=ACCENT, wrap="word",
                             highlightthickness=1, highlightbackground=BORDER,
                             highlightcolor=ACCENT, padx=10, pady=9)
        self.notes.grid(row=7, column=0, columnspan=2, sticky="nsew")
        fields.rowconfigure(7, weight=1)
        self.msg = label(form, size=9, bold=True, anchor="w", wraplength=430, justify="left")
        self.msg.pack(fill="x", pady=(10, 7))
        actions = tk.Frame(form, bg=CARD)
        # Reserve the save controls before letting the notes field take spare space.
        actions.pack(side="bottom", fill="x", before=fields)
        self.msg.pack_configure(side="bottom", before=fields)
        button(actions, "Save activity  →", self.save_entry, primary=True).pack(side="left")
        button(actions, "Clear", self.clear_form).pack(side="left", padx=10)
        label(actions, "Ctrl+S", size=8, color=MUTED).pack(side="right")

        side = tk.Frame(page, bg=BG)
        side.grid(row=0, column=1, sticky="nsew")
        outer, goal = card(side, padding=18)
        outer.pack(fill="x", pady=(0, 14))
        label(goal, "One goal. Lasting impact.", size=12, bold=True).pack(anchor="w")
        self.log_ring = ProgressRing(goal, size=140)
        self.log_ring.pack(pady=6)
        self.log_goal_caption = label(goal, size=10, color=ACCENT, bold=True)
        self.log_goal_caption.pack()
        label(goal, "Keep going. Your community feels it.", size=9, color=MUTED).pack(pady=(7, 0))
        outer, tips = card(side, padding=18)
        outer.pack(fill="both", expand=True)
        label(tips, "MAKE IT COUNT", size=8, color=TEAL, bold=True).pack(anchor="w", pady=(0, 13))
        for title, detail in (("01   Be specific", "Name the activity and organization."),
                              ("02   Track your time", "Log 0.25 to 24 hours per activity."),
                              ("03   Capture the moment", "Add a short note about your contribution.")):
            label(tips, title, size=10, bold=True).pack(anchor="w")
            label(tips, detail, size=9, color=MUTED, wraplength=250,
                  justify="left").pack(anchor="w", pady=(5, 9))

    def _build_records(self):
        outer, body = card(self.tab_rec, padding=16)
        outer.pack(fill="both", expand=True)
        filters = tk.Frame(body, bg=CARD)
        filters.pack(fill="x", pady=(0, 12))
        self.q = tk.StringVar()
        self.cat_f = tk.StringVar(value="All")
        label(filters, "Search", size=9, color=MUTED).pack(side="left", padx=(0, 8))
        ttk.Entry(filters, textvariable=self.q, width=26, font=(FONT, 10)).pack(side="left", fill="x", expand=True)
        label(filters, "Category", size=9, color=MUTED).pack(side="left", padx=(18, 8))
        category = ttk.Combobox(filters, textvariable=self.cat_f, state="readonly", width=16,
                                values=["All"] + vt.CATEGORIES, font=(FONT, 10))
        category.pack(side="left")
        category.bind("<<ComboboxSelected>>", lambda event: self.refresh_table())
        actions = tk.Frame(body, bg=CARD)
        actions.pack(fill="x", pady=(0, 14))
        self.record_count = label(actions, size=10, bold=True)
        self.record_count.pack(side="left")
        for title, command in (("Delete selected", self.delete_sel), ("Export reports", self.export),
                                ("Import CSV", self.import_csv), ("Demo data", self.demo)):
            button(actions, title, command, compact=True).pack(side="right", padx=(6, 0))
        table = tk.Frame(body, bg=CARD)
        table.pack(fill="both", expand=True)
        table.rowconfigure(0, weight=1)
        table.columnconfigure(0, weight=1)
        cols = ("id", "date", "activity", "category", "hours", "org")
        self.tree = ttk.Treeview(table, columns=cols, show="headings", selectmode="browse")
        for key, title, width in zip(cols, ("ID", "DATE", "ACTIVITY", "CATEGORY", "HOURS", "ORGANIZATION"),
                                      (42, 105, 210, 115, 75, 170)):
            self.tree.heading(key, text=title, command=lambda key=key: self.sort_by(key))
            self.tree.column(key, width=width, minwidth=width, anchor="center" if key in ("id", "hours") else "w")
        self.tree.tag_configure("even", background=CARD)
        self.tree.tag_configure("odd", background="#202a22")
        self.tree.tag_configure("warn", background="#423820", foreground=AMBER)
        vertical = ttk.Scrollbar(table, orient="vertical", command=self.tree.yview)
        horizontal = ttk.Scrollbar(table, orient="horizontal", command=self.tree.xview)
        self.tree.configure(yscrollcommand=vertical.set, xscrollcommand=horizontal.set)
        self.tree.grid(row=0, column=0, sticky="nsew")
        vertical.grid(row=0, column=1, sticky="ns")
        horizontal.grid(row=1, column=0, sticky="ew")
        self.empty_records = label(table, "No activities yet. Log your first contribution.",
                                   size=11, color=MUTED)
        label(body, "Click a column heading to sort.  •  Amber rows mark sessions of 12 hours or more.",
              size=8, color=MUTED).pack(anchor="w", pady=(11, 0))
        self.sort_key, self.sort_rev = "date", True
        self.q.trace_add("write", lambda *args: self.refresh_table())

    def _build_summary(self):
        page = self.tab_sum
        page.columnconfigure(0, weight=3, uniform="insights")
        page.columnconfigure(1, weight=2, uniform="insights")
        page.rowconfigure(0, weight=1)
        page.rowconfigure(1, weight=1)
        outer, categories = card(page, padding=18)
        outer.grid(row=0, column=0, sticky="nsew", padx=(0, 7), pady=(0, 14))
        label(categories, "Your impact mix", size=13, bold=True).pack(anchor="w")
        label(categories, "Hours contributed by category", size=9, color=MUTED).pack(anchor="w", pady=(4, 7))
        self.category_chart = CategoryChart(categories)
        self.category_chart.pack(fill="both", expand=True)
        outer, goal = card(page, padding=16)
        outer.grid(row=0, column=1, sticky="nsew", padx=(7, 0), pady=(0, 14))
        label(goal, "Your service goal", size=13, bold=True).pack(anchor="w")
        self.summary_ring = ProgressRing(goal, size=152)
        self.summary_ring.pack(expand=True)
        self.goal_lbl = label(goal, size=10, color=ACCENT, bold=True)
        self.goal_lbl.pack(pady=(0, 4))
        outer, report = card(page, padding=16)
        outer.grid(row=1, column=0, sticky="nsew", padx=(0, 7))
        label(report, "The full picture", size=12, bold=True).pack(anchor="w", pady=(0, 10))
        report_body = tk.Frame(report, bg=CARD)
        report_body.pack(fill="both", expand=True)
        self.txt = tk.Text(report_body, height=7, width=25, font=("Consolas", 9), bg=CARD,
                           fg=MUTED, relief="flat", wrap="none", highlightthickness=0,
                           selectbackground="#3c5130", selectforeground=TEXT)
        scroll = ttk.Scrollbar(report_body, orient="vertical", command=self.txt.yview)
        scroll_x = ttk.Scrollbar(report, orient="horizontal", command=self.txt.xview)
        self.txt.configure(yscrollcommand=scroll.set, xscrollcommand=scroll_x.set)
        scroll.pack(side="right", fill="y")
        self.txt.pack(fill="both", expand=True)
        scroll_x.pack(fill="x")
        outer, check = card(page, padding=16)
        outer.grid(row=1, column=1, sticky="nsew", padx=(7, 0))
        label(check, "Activity check-in", size=12, bold=True).pack(anchor="w")
        label(check, "A quick look at what needs your attention.", size=9,
              color=MUTED, wraplength=280, justify="left").pack(anchor="w", pady=(5, 13))
        self.warning_text = tk.Text(check, height=4, width=20, bg=CARD, fg=AMBER,
                                    font=(FONT, 10), wrap="word", relief="flat",
                                    highlightthickness=0, padx=0, pady=0)
        warning_scroll = ttk.Scrollbar(check, orient="vertical", command=self.warning_text.yview)
        self.warning_text.configure(yscrollcommand=warning_scroll.set)
        warning_scroll.pack(side="right", fill="y")
        self.warning_text.pack(fill="both", expand=True)

    def say(self, text, ok=True):
        self.msg.config(text=text, fg=ACCENT if ok else ERROR)

    def save_entry(self):
        try:
            entry_date = vt.validate_date(self.v["date"].get())
            activity = vt.validate_text(self.v["activity"].get(), "Activity")
            category = vt.validate_category(self.v["category"].get())
            duration = vt.validate_hours(self.v["hours"].get())
            organization = vt.validate_text(self.v["org"].get(), "Organization")
        except ValueError as err:
            self.say(f"Check your entry: {err}", ok=False)
            return
        record = vt.Record(vt.next_id(self.records), entry_date.isoformat(), activity, category,
                           duration, organization, self.notes.get("1.0", "end").strip()[:200])
        updated = self.records + [record]
        try:
            vt.save_records(updated)
        except OSError as err:
            self.say(f"Could not save your activity: {err}", ok=False)
            return
        self.records = updated
        note = " Please verify this long session." if duration >= vt.WARN_SINGLE_ENTRY else ""
        self.say(f"Activity saved. +{hours(duration)} hours of impact!{note}")
        self.clear_form(keep_msg=True)
        self.refresh_all()

    def clear_form(self, keep_msg=False):
        self.v["date"].set(date.today().isoformat())
        self.v["activity"].set("")
        self.v["org"].set("")
        self.v["hours"].set("1")
        self.v["category"].set(vt.CATEGORIES[0])
        self.notes.delete("1.0", "end")
        if not keep_msg:
            self.say("")
        self.activity_entry.focus_set()

    def sort_by(self, column):
        self.sort_rev = not self.sort_rev if self.sort_key == column else False
        self.sort_key = column
        self.refresh_table()

    def refresh_table(self):
        keyword, category = self.q.get().strip().lower(), self.cat_f.get()
        rows = [record for record in self.records
                if (not keyword or keyword in f"{record.activity} {record.organization} {record.notes}".lower())
                and (category == "All" or record.category == category)]
        attribute = {"org": "organization"}.get(self.sort_key, self.sort_key)
        rows.sort(key=lambda record: getattr(record, attribute), reverse=self.sort_rev)
        selected = self.tree.selection()
        self.tree.delete(*self.tree.get_children())
        for index, record in enumerate(rows):
            tag = "warn" if record.hours >= vt.WARN_SINGLE_ENTRY else "odd" if index % 2 else "even"
            self.tree.insert("", "end", iid=str(record.id), tags=(tag,),
                             values=(record.id, record.date, record.activity, record.category,
                                     f"{record.hours:.2f}", record.organization))
        if selected and self.tree.exists(selected[0]):
            self.tree.selection_set(selected[0])
        self.record_count.config(text=f"{len(rows)} activities  /  {hours(vt.total_hours(rows))} h")
        if rows:
            self.empty_records.place_forget()
        else:
            self.empty_records.config(text="No matching activities. Try another filter." if keyword or category != "All"
                                       else "No activities yet. Log your first contribution.")
            self.empty_records.place(relx=0.5, rely=0.45, anchor="center")
        self.status.set(f"{len(self.records)} activities  •  {hours(vt.total_hours(self.records))} hours contributed")

    def delete_sel(self):
        selected = self.tree.selection()
        if not selected:
            messagebox.showinfo("Select an activity", "Choose an activity in the table first.", parent=self)
            return
        record_id = int(selected[0])
        if messagebox.askyesno("Delete activity", f"Permanently delete activity #{record_id}?", parent=self):
            updated = [record for record in self.records if record.id != record_id]
            try:
                vt.save_records(updated)
            except OSError as err:
                messagebox.showerror("Could not delete activity", str(err), parent=self)
                return
            self.records = updated
            self.refresh_all()

    def export(self):
        try:
            vt.export_reports(self.records)
        except OSError as err:
            messagebox.showerror("Export failed", str(err), parent=self)
            return
        messagebox.showinfo("Reports exported", "Your CSV, TXT and Markdown reports are ready:\n"
                            + os.path.abspath("reports"), parent=self)

    def import_csv(self):
        path = filedialog.askopenfilename(parent=self, filetypes=[("CSV files", "*.csv")])
        if not path:
            return
        imported, errors = [], []
        try:
            with open(path, newline="", encoding="utf-8-sig") as source:
                reader = csv.DictReader(source)
                required = {"date", "activity", "category", "hours", "organization"}
                if not reader.fieldnames or not required <= {heading.strip().lower() for heading in reader.fieldnames}:
                    messagebox.showerror("Import CSV", "CSV needs columns: " + ", ".join(sorted(required)), parent=self)
                    return
                next_id = vt.next_id(self.records)
                for number, row in enumerate(reader, start=2):
                    row = {key.strip().lower(): (value or "") for key, value in row.items() if key}
                    try:
                        imported.append(vt.Record(
                            next_id, vt.validate_date(row["date"]).isoformat(),
                            vt.validate_text(row["activity"], "Activity"),
                            vt.validate_category(row["category"]), vt.validate_hours(row["hours"]),
                            vt.validate_text(row["organization"], "Organization"), row.get("notes", "")[:200]))
                        next_id += 1
                    except ValueError as err:
                        errors.append(f"row {number}: {err}")
            vt.save_records(self.records + imported)
        except (OSError, csv.Error, UnicodeDecodeError) as err:
            messagebox.showerror("Import failed", f"Could not import file: {err}", parent=self)
            return
        self.records.extend(imported)
        self.refresh_all()
        details = ""
        if errors:
            try:
                with open("import_errors.log", "w", encoding="utf-8") as log:
                    log.write("\n".join(errors))
                details = "\nDetails: import_errors.log"
            except OSError:
                details = "\n" + "\n".join(errors[:5])
        messagebox.showinfo("Import complete", f"Imported {len(imported)} activities. {len(errors)} rejected."
                            + details, parent=self)

    def demo(self):
        if self.records and not messagebox.askyesno("Demo activities", "Add demo data to your existing records?", parent=self):
            return
        vt.input = lambda *args: "y"
        try:
            vt.seed_demo(self.records)
        except OSError as err:
            messagebox.showerror("Demo data", str(err), parent=self)
        finally:
            del vt.input
        self.refresh_all()

    def _draw_sidebar_goal(self):
        self.sidebar_progress.delete("all")
        width = self.sidebar_progress.winfo_width()
        fraction = min(vt.total_hours(self.records) / vt.GOAL_HOURS, 1)
        self.sidebar_progress.create_rectangle(0, 0, width, 5, fill=BORDER, outline="")
        if fraction:
            self.sidebar_progress.create_rectangle(0, 0, width * fraction, 5, fill=ACCENT, outline="")

    def refresh_dashboard(self):
        total = vt.total_hours(self.records)
        monday = date.today() - timedelta(days=date.today().weekday())
        daily = [vt.total_hours([record for record in self.records
                                if record.date == (monday + timedelta(days=day)).isoformat()])
                 for day in range(7)]
        self.metric_values["total"].config(text=hours(total))
        self.metric_values["week"].config(text=hours(sum(daily)))
        self.metric_values["sessions"].config(text=str(len(self.records)))
        self.metric_values["orgs"].config(text=str(len({record.organization.casefold() for record in self.records})))
        self.dashboard_ring.set(total)
        self.log_ring.set(total)
        self.weekly_chart.set(daily)
        caption = f"{hours(total)} / {vt.GOAL_HOURS:g} hours contributed"
        self.goal_caption.config(text=caption)
        self.log_goal_caption.config(text=caption)
        remaining = max(0, vt.GOAL_HOURS - total)
        self.goal_remaining.config(text=f"{hours(remaining)} hours to your goal" if remaining else "Goal reached. Keep making an impact!")
        self.sidebar_goal.config(text=f"{hours(total)} / {vt.GOAL_HOURS:g} h goal")
        self._draw_sidebar_goal()
        # Avoid rebuilding the short list when only the current page changes.
        recent = sorted(self.records, key=lambda record: (record.date, record.id), reverse=True)[:3]
        signature = tuple((r.id, r.date, r.activity, r.category, r.hours, r.organization) for r in recent)
        if signature == getattr(self, "_recent_signature", None):
            return
        self._recent_signature = signature
        for widget in self.recent_area.winfo_children():
            widget.destroy()
        self.recent_rows = []
        if not recent:
            label(self.recent_area, "Your impact starts with one activity.", size=11, color=MUTED).pack(anchor="w", pady=(12, 10))
            button(self.recent_area, "+  Log your first activity", lambda: self.show_page("log"), primary=True).pack(anchor="w")
            return
        for record in recent:
            row = tk.Frame(self.recent_area, bg=CARD)
            self.recent_rows.append(row)
            color = CATEGORY_COLORS[vt.CATEGORIES.index(record.category)] if record.category in vt.CATEGORIES else ACCENT
            label(row, record.category[:1], size=11, color=color, bold=True,
                  width=3, pady=7).pack(side="left", padx=(0, 8))
            right = tk.Frame(row, bg=CARD)
            right.pack(side="right")
            label(right, f"+{hours(record.hours)} h", size=11, color=ACCENT, bold=True).pack(anchor="e")
            label(right, date.fromisoformat(record.date).strftime("%d %b %Y"), size=8, color=MUTED).pack(anchor="e")
            copy = tk.Frame(row, bg=CARD)
            copy.pack(side="left", fill="x", expand=True)
            label(copy, short(record.activity, 54), size=10, bold=True, anchor="w").pack(fill="x")
            label(copy, short(f"{record.category}  ·  {record.organization}", 65), size=8, color=MUTED, anchor="w").pack(fill="x", pady=(2, 0))
        self.after_idle(self._layout_recent)

    def _layout_recent(self):
        if not self.recent_rows:
            return
        available = self.recent_area.winfo_height()
        for row in self.recent_rows:
            row.pack_forget()
            required = row.winfo_reqheight() + 6
            if required <= available:
                row.pack(fill="x", pady=3)
                available -= required

    def refresh_summary(self):
        total = vt.total_hours(self.records)
        self.summary_ring.set(total)
        self.goal_lbl.config(text=f"{hours(total)} / {vt.GOAL_HOURS:g} hours")
        self.category_chart.set(vt.hours_by(self.records, lambda record: record.category))
        self.txt.config(state="normal")
        self.txt.delete("1.0", "end")
        self.txt.insert("1.0", vt.summary_text(self.records))
        self.txt.config(state="disabled")
        warnings = vt.warnings_for(self.records)
        self.warning_text.config(state="normal", fg=AMBER if warnings else TEAL)
        self.warning_text.delete("1.0", "end")
        self.warning_text.insert("1.0", "\n\n".join("•  " + warning for warning in warnings)
                                 if warnings else "All clear.\n\nNo activity warnings. Keep up your momentum.")
        self.warning_text.config(state="disabled")

    def refresh_all(self):
        self.refresh_table()
        self.refresh_summary()
        self.refresh_dashboard()


if __name__ == "__main__":
    App().mainloop()

